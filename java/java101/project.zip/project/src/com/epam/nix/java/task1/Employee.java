package com.epam.nix.java.task1;

public class Employee {

    private String name;
    private String surname;
    private int age;
    private String department;

    public String getName() {
        return name;
    }

    public String getSurname() {
        return surname;
    }

    public int getAge() {
        return age;
    }

    public String getDepartment() {
        return department;
    }
}
